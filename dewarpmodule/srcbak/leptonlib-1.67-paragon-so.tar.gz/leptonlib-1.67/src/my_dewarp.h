#ifndef MY_DEWARP_H
#define MY_DEWARP_H
#include "allheaders.h"
int my_dewarp (char	 *input_file,char *output_file);
#endif